package com.ecommerce.electronicos.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ecommerce.electronicos.model.Dispositivo;
import com.ecommerce.electronicos.model.Usuario;
import com.ecommerce.electronicos.service.DispositivoService;
import com.ecommerce.electronicos.service.FotoService;
import com.ecommerce.electronicos.service.UsuarioService;

@Controller
@RequestMapping("/dispositivos")
public class DispositivoController {
    
    private final DispositivoService dispositivoService;
    private final UsuarioService usuarioService;
    private final FotoService fotoservice;
    
    public DispositivoController(DispositivoService dispositivoService, UsuarioService usuarioService, FotoService fotoservice) {
        this.dispositivoService = dispositivoService;
        this.usuarioService = usuarioService;
        this.fotoservice = fotoservice;
    }
    
    @GetMapping({"","/"})
public String listarDispositivos(
        @RequestParam(required = false) String busqueda,
        @RequestParam(required = false) String categoria,
        @RequestParam(required = false) Double precioMin,
        @RequestParam(required = false) Double precioMax,
        @RequestParam(required = false) String departamento,
        @RequestParam(required = false) String municipio,
        @RequestParam(required = false) String marca,
        @RequestParam(required = false) String ordenPrecio,
        @RequestParam(defaultValue = "0") int page,
        Model model) {

    int cantidadPorPagina = 20;

    // Llamamos al nuevo servicio que hace todo el trabajo mágico
    Page<Dispositivo> pagina = dispositivoService.buscarDispositivosConFiltros(
            busqueda, categoria, precioMin, precioMax, departamento, municipio, marca, ordenPrecio, page, cantidadPorPagina);

    // Mandamos los datos a la vista
    model.addAttribute("dispositivos", pagina.getContent());
    model.addAttribute("totalDispositivos", pagina.getTotalElements());
    model.addAttribute("currentPage", page);
    model.addAttribute("totalPages", pagina.getTotalPages());

    // Mantenemos los filtros para que los botones de HTML tengan memoria
    model.addAttribute("categorias", List.of("Smartphones", "Laptops", "Tablets", "Consolas", "Audio", "Televisores", "Accesorios", "Otros"));
    model.addAttribute("categoriaSeleccionada", categoria);
    model.addAttribute("precioMinSeleccionado", precioMin);
    model.addAttribute("precioMaxSeleccionado", precioMax);
    model.addAttribute("departamentoSeleccionado", departamento);
    model.addAttribute("municipioSeleccionado", municipio);
    model.addAttribute("marcaSeleccionada", marca);
    model.addAttribute("ordenSeleccionado", ordenPrecio);
    model.addAttribute("busqueda", busqueda);

    return "dispositivos/lista";
}


    @GetMapping("/{id}")
public String verDetalleDispositivo(@PathVariable String id, Model model) {
    // Usamos el servicio para buscar el dispositivo por ID
    Optional<Dispositivo> dispositivoOpt = dispositivoService.obtenerPorId(id);
    
    if (dispositivoOpt.isPresent()) {
        model.addAttribute("dispositivo", dispositivoOpt.get());
        return "dispositivos/detalle"; // Esta es la nueva plantilla que crearemos
    } else {
        return "redirect:/dispositivos?error=Dispositivo+no+encontrado";
    }
}
    
    @GetMapping("/nuevo")
public String mostrarFormulario(Model model) {
    model.addAttribute("dispositivo", new Dispositivo());
    
    return "dispositivos/formulario";
}
    
   @PostMapping("/guardar")
    public String guardarDispositivo(@ModelAttribute Dispositivo dispositivo,
                                     @RequestParam(value = "foto", required = false) MultipartFile foto,
                                     Authentication authentication,
                                     RedirectAttributes redirectAttributes) {
 
        if (authentication == null) {
            return "redirect:/login";
        }
 
        String email = authentication.getName();
        Optional<Usuario> usuarioOpt = usuarioService.obtenerPorEmail(email);
 
        if (usuarioOpt.isPresent()) {
 
            //funcion para subir la foto y guardarla
            try {
                if (foto != null && !foto.isEmpty()) {
                    dispositivo.setImagenUrl(fotoservice.subir(foto));
                }
            } catch (Exception e) {
                e.printStackTrace();
                redirectAttributes.addFlashAttribute("error", "No se pudo subir la imagen: " + e.getMessage());
                return "redirect:/dispositivos/nuevo";
            }

            //el minimo del stock para k sea valido
            if(dispositivo.getStock() < 1){
                dispositivo.setStock(1);
            }
            dispositivo.setDisponible(true);
 
            dispositivo.setVendedor(usuarioOpt.get());
            dispositivoService.crearDispositivo(dispositivo);
            redirectAttributes.addFlashAttribute("mensaje", "Producto publicado exitosamente");
        } else {
            redirectAttributes.addFlashAttribute("error", "Error al identificar usuario");
        }
        return "redirect:/dispositivos";
    }

    //editar un dispositivo
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable String id,
                                          Authentication authentication,
                                          Model model,
                                          RedirectAttributes redirectAttributes) {
        if (authentication == null) return "redirect:/login";
 
        Optional<Dispositivo> dispositivoOpt = dispositivoService.obtenerPorId(id);
        if (dispositivoOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Dispositivo no encontrado");
            return "redirect:/dispositivos";
        }
 
        Dispositivo dispositivo = dispositivoOpt.get();
        String email = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        boolean isOwner = dispositivo.getVendedor() != null &&
                          dispositivo.getVendedor().getEmail().equals(email);
 
        if (!isAdmin && !isOwner) {
            redirectAttributes.addFlashAttribute("error", "No tienes permiso para editar este producto");
            return "redirect:/dispositivos";
        }
 
        model.addAttribute("dispositivo", dispositivo);
        return "dispositivos/editar";     // ← va a templates/dispositivos/editar.html
    }

    //guardar la ediccion
    @PostMapping("/editar/{id}")
    public String guardarEdicion(@PathVariable String id,
                                 @ModelAttribute Dispositivo dispositivoEditado,
                                 @RequestParam(value = "stock",required = false) Integer stock,
                                 @RequestParam(value = "foto", required = false) MultipartFile foto, 
                                 Authentication authentication,
                                 RedirectAttributes redirectAttributes) {
        if (authentication == null) return "redirect:/login";
 
        Optional<Dispositivo> dispositivoOpt = dispositivoService.obtenerPorId(id);
        if (dispositivoOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Dispositivo no encontrado");
            return "redirect:/dispositivos";
        }
 
        Dispositivo original = dispositivoOpt.get();
        String email = authentication.getName();
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        boolean isOwner = original.getVendedor() != null &&
                          original.getVendedor().getEmail().equals(email);
 
        if (!isAdmin && !isOwner) {
            redirectAttributes.addFlashAttribute("error", "No tienes permiso para editar este producto");
            return "redirect:/dispositivos";
        }
 
        // Conservar id, vendedor y fecha original
        dispositivoEditado.setId(id);
        dispositivoEditado.setVendedor(original.getVendedor());
        dispositivoEditado.setFechaPublicacion(original.getFechaPublicacion());
        
        // funcion para formulario lo envía sie el stock es >=1 se usa; si no, se mantiene el que ya tenía
        if (stock != null && stock >= 1){
            dispositivoEditado.setStock(stock);
        }else{
            dispositivoEditado.setStock(original.getStock());
        }
        dispositivoEditado.setDisponible(dispositivoEditado.getStock() > 0);
 
        // foto nueva si se subio una, si no se conserva la actual
        try {
            if (foto != null && !foto.isEmpty()) {
                dispositivoEditado.setImagenUrl(fotoservice.subir(foto));
            } else {
                dispositivoEditado.setImagenUrl(original.getImagenUrl());
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "No se pudo subir la imagen: " + e.getMessage());
            return "redirect:/dispositivos/editar/" + id;
        }
 
        dispositivoService.actualizarDispositivo(dispositivoEditado);
        redirectAttributes.addFlashAttribute("mensaje", "Producto actualizado correctamente");
        return "redirect:/dispositivos";
    }
    
    @GetMapping("/eliminar/{id}")
    public String eliminarDispositivo(@PathVariable String id, 
                                      Authentication authentication,
                                      RedirectAttributes redirectAttributes) {
        if (authentication == null) {
            return "redirect:/login";
        }
        
        Optional<Dispositivo> dispositivoOpt = dispositivoService.obtenerPorId(id);
        if (dispositivoOpt.isPresent()) {
            Dispositivo dispositivo = dispositivoOpt.get();
            String email = authentication.getName();
            
            // Verificar si es admin
            boolean isAdmin = authentication.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
            
            // Verificar si es el dueño del producto
            boolean isOwner = false;
            Optional<Usuario> usuarioOpt = usuarioService.obtenerPorEmail(email);
            if (usuarioOpt.isPresent() && dispositivo.getVendedor() != null) {
                isOwner = dispositivo.getVendedor().getId().equals(usuarioOpt.get().getId());
            }
            
            if (isAdmin || isOwner) {
                dispositivoService.eliminarDispositivo(id);
                redirectAttributes.addFlashAttribute("mensaje", "Producto eliminado correctamente");
            } else {
                redirectAttributes.addFlashAttribute("error", "No tienes permiso para eliminar este producto");
            }
        }
        return "redirect:/dispositivos";
    }
    
    @GetMapping("/detalle/{id}")
    public String verDetalle(@PathVariable String id, Model model) {
        Optional<Dispositivo> dispositivoOpt = dispositivoService.obtenerPorId(id);
        if (dispositivoOpt.isPresent()) {
            model.addAttribute("dispositivo", dispositivoOpt.get());
            return "dispositivos/detalle";
        }
        return "redirect:/dispositivos";
    }
}